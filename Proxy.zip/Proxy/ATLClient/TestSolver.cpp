#include "TestSolver.h"

int TestSolver::Add(int x, int y) {
	return x + y ;
}

int TestSolver::Sub(int x, int y) {
	return x - y ;
}
