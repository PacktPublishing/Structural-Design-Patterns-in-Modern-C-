#include "RealSubject.h"

#include <iostream>

void RealSubject::Request() {
	std::cout << "[RealSubject] Request processed\n";
}
