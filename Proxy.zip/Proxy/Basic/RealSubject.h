#pragma once
#include "Subject.h"
class RealSubject :
	public Subject
{
public:
	void Request() override;
};

