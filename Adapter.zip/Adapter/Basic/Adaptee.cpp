#include "Adaptee.h"
#include <iostream>

void Adaptee::SpecificRequest() {
	std::cout << "[Adaptee] SpecificRequest\n" ;
}
