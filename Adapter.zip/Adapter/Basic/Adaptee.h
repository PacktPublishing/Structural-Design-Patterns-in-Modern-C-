#pragma once
class Adaptee
{
public :
	void SpecificRequest() ;
};

