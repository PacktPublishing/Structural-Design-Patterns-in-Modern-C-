#include "B.h"

void B::CallB() {
}
