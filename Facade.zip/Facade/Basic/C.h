#pragma once
class C
{
public:
	void CallC() ;
};

