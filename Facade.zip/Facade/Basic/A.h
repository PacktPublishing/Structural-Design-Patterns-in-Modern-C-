#pragma once
class A
{
public:
	void CallA() ;
};

