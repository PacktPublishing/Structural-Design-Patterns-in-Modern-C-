#pragma once
class B
{
public:
	void CallB() ;
};

