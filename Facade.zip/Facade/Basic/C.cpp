#include "C.h"

void C::CallC() {
}
