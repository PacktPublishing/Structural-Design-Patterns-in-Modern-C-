#include "Client.h"

int main() {
	Client c ;
	c.Invoke() ;
}
