#include "A.h"

void A::CallA() {
}
