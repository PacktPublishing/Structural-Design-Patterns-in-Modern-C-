#pragma once
class Shape
{
public:
	virtual void Draw() = 0 ;
	virtual ~Shape() = default ;
};

