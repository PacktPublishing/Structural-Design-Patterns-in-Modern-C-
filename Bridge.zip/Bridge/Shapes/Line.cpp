#include "Line.h"

void Line::Draw() {
	m_pWindow->DrawLine(m_Start, m_End) ;
}
