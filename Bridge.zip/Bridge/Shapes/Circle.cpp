#include "Circle.h"

void Circle::Draw() {
	m_pWindow->DrawCircle(m_Position, m_Radius) ;
}
