#include "ConcreteImplementorB.h"

#include <iostream>

void ConcreteImplementorB::OperationImpl() {
	std::cout << "[ConcreteImplementorB] Implementation invoked\n" ;
}
