#pragma once
class Implementor
{
public:
	virtual void OperationImpl() = 0 ;
	virtual ~Implementor()=default ;
};

