#include "ConcreteImplementorA.h"

#include <iostream>

void ConcreteImplementorA::OperationImpl() {
	std::cout << "[ConcreteImplementorA] Implementation invoked\n" ;
}
