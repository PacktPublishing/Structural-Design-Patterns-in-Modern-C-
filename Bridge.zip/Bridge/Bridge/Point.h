#pragma once
struct Point
{
	float x{} ;
	float y{} ;
};

