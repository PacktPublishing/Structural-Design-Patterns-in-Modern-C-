#include "ConcreteComponent.h"

#include <iostream>

void ConcreteComponent::Operation() {
	std::cout << "[ConcreteComponent] Operation invoked\n" ;
}
