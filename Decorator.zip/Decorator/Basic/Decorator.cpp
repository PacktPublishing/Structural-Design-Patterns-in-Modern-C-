#include "Decorator.h"

void Decorator::Operation() {
	m_ptr->Operation() ;
}
