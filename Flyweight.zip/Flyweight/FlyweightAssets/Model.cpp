#include "Model.h"

void Model::Render() {
}

void Model::Render(Position3D position) {
}
