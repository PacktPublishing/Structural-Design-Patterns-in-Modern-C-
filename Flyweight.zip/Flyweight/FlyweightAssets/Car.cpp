#include "Car.h"

void Car::Render() {
	
}
